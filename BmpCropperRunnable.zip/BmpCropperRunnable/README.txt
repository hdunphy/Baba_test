To run BmpCropper
1. Extract files from zip folder
2. Open Command Prompt
3. Change directory to BmpCropperRunnable folder
4. Run command 'start BmpCropper.exe' on Command Prompt
5. Check 'fozzie-out.bmp' for output file.

If you want to change the input file it must be an 8bit .bmp file named 'fozzie-in.bmp' in the same folder as the BmpCropper.exe file.

-Henry Dunphy
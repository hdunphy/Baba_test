/*
* Created by Henry Dunphy 6/16/2021
*/
#pragma once

#include <vector>
const int informationHeaderSize = 40;
const int fileHeaderSize = 14;

struct Color {
	float R, G, B;

	Color();
	Color(float r, float g, float b);
	bool IsMagenta();
	~Color();
};

class Image
{
public:
	Image(int width, int height);
	~Image();

	void Read(const char* path);
	void Trim();
	void ExportSelf(const char* path);
private:
	int m_width;
	int m_height;
	int m_colorTableSize;
	std::vector<Color> m_colors;
	std::vector<int> m_colorIndex;
	Color m_colorTable[256];

	unsigned char m_FileHeader[14];
	unsigned char m_InformationHeader[40];

	bool IsRowMagenta(int column);
	bool IsColumnMagenta(int row);
};


/*
* Created by Henry Dunphy 6/16/2021
*/
#include "Image.h"

#include <iostream>
#include <fstream>

Color::Color()
	:R(0), G(0), B(0)
{
}

Color::Color(float r, float g, float b)
	: R(r), G(g), B(b)
{
}

/**
* Is Magenta checks current color. If it is magenta (1,0,1) then return true, else return false;
* Returns: bool
*/
bool Color::IsMagenta() {
	return R == 1.0f && G == 0.0f && B == 1.0f;
}

Color::~Color()
{
}

/**
* Constructor for Image class
* Parameters
*	int width to set the width of the image
*	int height to set the height of the image
*/
Image::Image(int width, int height)
	:m_width(width), m_height(height), m_colorTableSize(0), m_colors(std::vector<Color>(width* height)),
	m_colorIndex(std::vector<int>(width* height)), m_FileHeader(), m_InformationHeader()
{
}

Image::~Image()
{
}

/**
* Reads a file path and converts bytes into Image class
* Paramaters
*	const char* path: path string for BMP file to be read
*/
void Image::Read(const char* path)
{
	std::ifstream f; //open file from path to be read in as binary data
	f.open(path, std::ios::in | std::ios::binary);

	//Make sure file is open else exit function
	if (!f.is_open()) {
		std::cout << "Reading File could not be opened";
		return;
	}

	//First 14 bytes are the File Header information
	f.read(reinterpret_cast<char*>(m_FileHeader), fileHeaderSize);

	//Check the first two bytes to be BM which denotes a bmp file
	//Else exit function with console error
	if (m_FileHeader[0] != 'B' || m_FileHeader[1] != 'M') {
		std::cout << "The specified path is not a bitmap image" << std::endl;
		f.close();
		return;
	}

	//Next 40 bytes are the file's information header
	f.read(reinterpret_cast<char*>(m_InformationHeader), informationHeaderSize);

	//bytes 3-6 in file header are the file size
	int fileSize = m_FileHeader[2] + (m_FileHeader[3] << 8) + (m_FileHeader[4] << 16) + (m_FileHeader[5] << 24);

	//the width and height are in the information header bytes 5-8 and 9-12 respectively
	m_width = m_InformationHeader[4] + (m_InformationHeader[5] << 8) + (m_InformationHeader[6] << 16) + (m_InformationHeader[7] << 24);
	m_height = m_InformationHeader[8] + (m_InformationHeader[9] << 8) + (m_InformationHeader[10] << 16) + (m_InformationHeader[11] << 24);

	//planes, bitsPerpixel, image size are all contained in the information header and read here for debugging
	int planes = m_InformationHeader[12] + (m_InformationHeader[13] << 8);
	int bitsPerPixel = m_InformationHeader[14] + (m_InformationHeader[15] << 8);
	int imgSize = m_InformationHeader[20] + (m_InformationHeader[21] << 8) + (m_InformationHeader[22] << 16) + (m_InformationHeader[23] << 24);
	//color table size (information header bytes 33-36) gets the size of the Color look up table which is stored after the information header
	m_colorTableSize = m_InformationHeader[32] + (m_InformationHeader[33] << 8) + (m_InformationHeader[34] << 16) + (m_InformationHeader[35] << 24);
	//important colors is related to the color table but was not needed for this task
	int importantColors = m_InformationHeader[36] + (m_InformationHeader[37] << 8) + (m_InformationHeader[38] << 16) + (m_InformationHeader[39] << 24);

	//iterate through the color table using the color table size.
	//Each color is 4 bytes in RGBA format, but alpha is unneeded in this task
	for (int i = 0; i < m_colorTableSize; i++) {
		unsigned char color[4]; //RGBA each are one byte
		f.read(reinterpret_cast<char*>(color), 4);

		//convert unsigned char (byte) to float for human readability
		m_colorTable[i].R = static_cast<float>(color[2]) / 255.0f; //color stored as BGR so R is the 3rd byte
		m_colorTable[i].G = static_cast<float>(color[1]) / 255.0f; //G is still 2nd byte
		m_colorTable[i].B = static_cast<float>(color[0]) / 255.0f; //B is the 1st byte
		//Ignoring the last byte since it is unused in this project
	}
	//Print to console reader position for debugging
	std::cout << "After color table (read) " << f.tellg() << std::endl;

	//set size of the color array and color index array
	m_colors.resize(m_width * m_height); //Vector<color>
	m_colorIndex.resize(m_width * m_height); //Vector<int>

	//BMP files must have rows divisible by 4 bytes
	//Find padding to put at the end of each row
	//	Get the Width % 4 value to get the remainder when divided by 4
	//	subtract the remainder from 4 to determine how much padding is needed
	//	Take that number and mod 4 incase the width is divisible by 4 then 4-0 = 4 
	//		and we don't want an extra 4 padding
	const int paddingAmount = ((4 - (m_width) % 4) % 4);

	//Iterate through height and width to get all the colors from the bmp color array
	//In 8bit bmp files the color array is an array of ints that correlate to an index in the color table
	for (int y = 0; y < m_height; y++) {
		for (int x = 0; x < m_width; x++) {
			//Read in one byte at a time
			unsigned char position[1];
			f.read(reinterpret_cast<char*>(position), 1);

			int positionIndex = static_cast<int>(position[0]);
			int index = y * m_width + x;
			m_colorIndex[index] = positionIndex; //store the color index
			m_colors[index] = m_colorTable[positionIndex]; //store the actual color
		}
		//ignore the padding
		f.ignore(paddingAmount);
	}
	//Print to console reader position for debugging
	std::cout << "After color data (read) " << f.tellg() << std::endl;

	// check for EOF for debugging
	if (f.eof())                      
		std::cout << "[EoF (read) reached]\n";
	else {
		f.seekg(0, std::ios::end);
		std::cout << "[error reading] eof at: " << f.tellg() << std::endl;
	}

	//close file
	f.close();

	//print out file read for debugging
	std::cout << "File Read" << std::endl << std::endl;
}

/**
* Trim off all the extra magenta space around the main image.
*/
void Image::Trim()
{
	int minHeight = 0;
	int maxHeight = m_height;
	int minWidth = 0;
	int maxWidth = m_width;

	//iterate through the rows to find the min height
	for (int row = 0; row < m_height; row++) {
		if (IsRowMagenta(row))
			minHeight = row + 1; //if column was magenta update minHeight
		else break; //else exit loop and minHeight will equal row
	}

	//iterate through the rows to find the max height
	//Go backwards from image height to 0
	for (int row = m_height - 1; row >= 0; row--) {
		if (IsRowMagenta(row))
			maxHeight = row; //if column was magenta update max height
		else break; //else exit loop and maxheight will be equal to row + 1
	}

	//iterate through the columns to find the min width
	for (int col = 0; col < m_width; col++) {
		if (IsColumnMagenta(col)) //if row was magenta update minWidth
			minWidth = col + 1;//else exit loop and minWidth will be equal to column
		else break;
	}

	//iterate through the columns to find the max width
	//Go backwards from image height to 0
	for (int col = m_width - 1; col >= 0; col--) {
		if (IsColumnMagenta(col)) //if row was magenta update maxWidth
			maxWidth = col;//else exit loop and maxWidth will be equal to column + 1
		else break;
	}

	//print bounds for debugging
	std::cout << "min width (" << minWidth
		<< ") max width (" << maxWidth
		<< ") min height (" << minHeight
		<< ") max height" << maxHeight << std::endl;

	//store old width for getting color index
	int oldWidth = m_width;
	//Get difference between widths
	m_width = maxWidth - minWidth;
	//Get difference between heights
	m_height = maxHeight - minHeight;
	//initialize posBuff with new w, h
	std::vector<int> positionBuffer = std::vector<int>(m_width * m_height);
	//fill in posBuff by starting from min and ending at max 2d loop
	int index = 0; //for index of the position buffer
	for (int y = minHeight; y < maxHeight; y++) {
		for (int x = minWidth; x < maxWidth; x++) {
			positionBuffer[index++] = m_colorIndex[y * oldWidth + x];
		}
	}
	//resize vector<int> replace with posBuff
	m_colorIndex.resize(m_width * m_height);
	m_colorIndex = positionBuffer;

	//find padding for colors
	const int paddingAmount = ((4 - (m_width) % 4) % 4);
	//update filesize = header (54) + colorTable size (1024) + width * height + padding * height
	int fileSize = fileHeaderSize + informationHeaderSize + m_colorTableSize * 4 + m_width * m_height + paddingAmount * m_height;
	int imageSize = m_width * m_height;

	//Update file size in header
	m_FileHeader[2] = fileSize;
	m_FileHeader[3] = fileSize >> 8;
	m_FileHeader[4] = fileSize >> 16;
	m_FileHeader[5] = fileSize >> 24;

	//Image width
	m_InformationHeader[4] = m_width;
	m_InformationHeader[5] = m_width >> 8;
	m_InformationHeader[6] = m_width >> 16;
	m_InformationHeader[7] = m_width >> 24;
	//Image height
	m_InformationHeader[8] = m_height;
	m_InformationHeader[9] = m_height >> 8;
	m_InformationHeader[10] = m_height >> 16;
	m_InformationHeader[11] = m_height >> 24;

	//Image size
	m_InformationHeader[20] = imageSize;
	m_InformationHeader[21] = imageSize >> 8;
	m_InformationHeader[22] = imageSize >> 16;
	m_InformationHeader[23] = imageSize >> 24;
}



/**
* Exports the current image object to a bmp file at the given path destination
* Paramaters
*	const char* path: file path string for BMP file to be exported to
*/
void Image::ExportSelf(const char* path)
{
	std::ofstream f;
	f.open(path, std::ios::out | std::ios::binary); //write to file in binary

	//Make sure file is open else exit function
	if (!f.is_open()) {
		std::cout << "File Write could not be opened";
		return;
	}

	//write the File Header (14 bytes) and the Information Header (40 bytes)
	f.write(reinterpret_cast<char*>(m_FileHeader), fileHeaderSize);
	f.write(reinterpret_cast<char*>(m_InformationHeader), informationHeaderSize);

	//Iterate through the color table and write to file since this is an 8bit BMP
	for (int i = 0; i < m_colorTableSize; i++) {
		//convert the Color object back to three bytes. Multiply by 255 to go from (0-1 float scale) to unsiged char 0-255
		unsigned char r = static_cast<unsigned char>(m_colorTable[i].R * 255.0f);
		unsigned char g = static_cast<unsigned char>(m_colorTable[i].G * 255.0f);
		unsigned char b = static_cast<unsigned char>(m_colorTable[i].B * 255.0f);

		//Color table use RGBA but in order of BGRA. Alpha was unused in this project
		unsigned char color[] = { b,g,r,0 };

		f.write(reinterpret_cast<char*>(color), 4);
	}
	//Print to console reader position for debugging
	std::cout << "After color table (write) " << f.tellp() << std::endl;

	//Padding is an empty byte
	unsigned char bmpPad[1] = { 0 };
	//Calculate padding amount as described in Read function
	const int paddingAmount = ((4 - (m_width) % 4) % 4);

	//iterate through the color index (vector<int>) and write to file with padding
	for (int y = 0; y < m_height; y++) {
		for (int x = 0; x < m_width; x++) {
			//convert int back to byte
			unsigned char index = static_cast<unsigned char>(m_colorIndex[y * m_width + x]);

			unsigned char position[] = { index };

			//write index position to file
			f.write(reinterpret_cast<char*>(position), sizeof(position));
		}
		//write padding to file to keep with BMP file format
		f.write(reinterpret_cast<char*>(bmpPad), paddingAmount);
	}

	//Print to console reader position for debugging
	std::cout << "After color data (write) " << f.tellp() << std::endl;

	// check for EOF for debugging
	if (f.eof())                      
		std::cout << "[EoF (write) reached]\n";
	else {
		f.seekp(0, std::ios::end);
		std::cout << "[error writing] eof at: " << f.tellp() << std::endl;
	}

	f.close();

	//print function completed for debugging
	std::cout << "Self File Created\n\n";
}

/**
* Checks if the row is all magenta pixels
* Parameters
*	int row is the row index that is kept constant while checking all pixels in that row
* returns true if row is all magenta. Returns false if contains other color pixel
*/
bool Image::IsRowMagenta(int row)
{
	for (int i = 0; i < m_height; i++) {
		int index = row * m_width + i;
		if (!m_colors[index].IsMagenta()) {
			return false;
		}
	}
	return true;
}

/**
* Checks if the column is all magenta pixels
* Parameters
*	int col is the col index that is kept constant while checking all pixels in that column
* returns true if column is all magenta. Returns false if contains other color pixel
*/
bool Image::IsColumnMagenta(int col)
{
	for (int i = 0; i < m_width; i++) {
		int index = i * m_width + col;
		if (!m_colors[index].IsMagenta()) {
			return false;
		}
	}
	return true;
}
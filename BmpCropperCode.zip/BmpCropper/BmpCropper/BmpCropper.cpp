/*
* Created by Henry Dunphy 6/16/2021
*/

// BmpCropper.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "Image.h"


int main()
{
	Image image(0, 0);

	image.Read("fozzie-in.bmp");
	image.Trim();
	image.ExportSelf("fozzie-out.bmp");
}
